"use client"

import { useRouter } from "next/navigation"
import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import api from "@/api"

export function RegisterForm({ role }: { role: "client" | "freelancer" }) {
  const router = useRouter()

  const [loading, setLoading] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [name, setName] = useState("")
  const [company, setCompany] = useState("")
  const [faceImage, setFaceImage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [passwordStrength, setPasswordStrength] = useState(0)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  const checkPasswordStrength = (password: string) => {
    let strength = 0
    if (password.length >= 8) strength++
    if (/[A-Z]/.test(password)) strength++
    if (/[0-9]/.test(password)) strength++
    if (/[^A-Za-z0-9]/.test(password)) strength++
    return strength
  }

  useEffect(() => {
    setPasswordStrength(checkPasswordStrength(password))
  }, [password])

  // Face capture for freelancers
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 320, height: 240 } 
      })
      if (videoRef.current) {
        videoRef.current.srcObject = stream
      }
    } catch (err) {
      setError("Unable to access camera. Please check permissions.")
    }
  }

  const captureFace = () => {
    if (videoRef.current && canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d')
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0, 320, 240)
        const imageData = canvasRef.current.toDataURL('image/jpeg')
        setFaceImage(imageData)
        
        // Stop camera
        const stream = videoRef.current.srcObject as MediaStream
        stream?.getTracks().forEach(track => track.stop())
      }
    }
  }

  const retakeFace = () => {
    setFaceImage(null)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (passwordStrength < 2) {
      setError("Password too weak.")
      return
    }

    // Freelancer must have face image
    if (role === "freelancer" && !faceImage) {
      setError("Face capture is required for freelancers.")
      return
    }

    setLoading(true)
    setError(null)

    const payload =
      role === "client"
        ? { email, password, company_name: company, role }
        : { email, password, full_name: name, role, face_image: faceImage }

    try {
      const res = await api.post("accounts/register/", payload)

      console.log("Registration success:", res.data)

      router.push("/login")
    } catch (err: any) {
      console.error(err)

      const message =
        err?.response?.data?.email?.[0] ||
        err?.response?.data?.detail ||
        err?.response?.data?.message ||
        err?.response?.data?.face_image?.[0] ||
        err?.response?.data?.full_name?.[0] ||
        err?.response?.data?.company_name?.[0] ||
        "Registration failed."

      setError(message)
    } finally {
      setLoading(false)
    }
  }

  const getStrengthLabel = (level: number) => {
    switch (level) {
      case 0:
      case 1:
        return { text: "Weak", color: "bg-red-500" }
      case 2:
        return { text: "Medium", color: "bg-yellow-500" }
      case 3:
      case 4:
        return { text: "Strong", color: "bg-green-600" }
      default:
        return { text: "Checking...", color: "bg-gray-300" }
    }
  }

  const strength = getStrengthLabel(passwordStrength)

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle>
          Sign up as {role === "client" ? "Client" : "Freelancer"}
        </CardTitle>
        <CardDescription>
          {role === "client"
            ? "Hire top talent for your project."
            : "Showcase skills and land great gigs."}
        </CardDescription>
      </CardHeader>

      <CardContent>
        <form className="space-y-4" onSubmit={handleSubmit}>
          {role === "client" ? (
            <div className="grid gap-2">
              <Label htmlFor="company">Company Name</Label>
              <Input
                id="company"
                placeholder="Acme Inc."
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                required
              />
            </div>
          ) : (
            <>
              <div className="grid gap-2">
                <Label htmlFor="fullname">Full name</Label>
                <Input
                  id="fullname"
                  placeholder="Jane Doe"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>

              {/* Face Capture for Freelancers */}
              <div className="grid gap-2 border-t pt-4">
                <Label>Face Capture (Required)</Label>
                {!faceImage ? (
                  <div className="space-y-2">
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      className="w-full rounded-lg bg-black"
                      style={{ maxHeight: "240px" }}
                    />
                    <canvas
                      ref={canvasRef}
                      width={320}
                      height={240}
                      className="hidden"
                    />
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={startCamera}
                        className="flex-1"
                      >
                        Start Camera
                      </Button>
                      <Button
                        type="button"
                        variant="default"
                        onClick={captureFace}
                        className="flex-1"
                      >
                        Capture Face
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <img
                      src={faceImage}
                      alt="Captured face"
                      className="w-full rounded-lg"
                      style={{ maxHeight: "240px" }}
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={retakeFace}
                      className="w-full"
                    >
                      Retake Photo
                    </Button>
                  </div>
                )}
              </div>
            </>
          )}

          <div className="grid gap-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="you@company.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />

            {password && (
              <div className="mt-1">
                <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className={`h-2 transition-all duration-300 ${strength.color}`}
                    style={{ width: `${(passwordStrength / 4) * 100}%` }}
                  />
                </div>

                <p className="text-sm mt-1 font-medium text-gray-700">
                  Strength:{" "}
                  <span className={`font-semibold ${strength.color.replace("bg", "text")}`}>
                    {strength.text}
                  </span>
                </p>
              </div>
            )}
          </div>

          {error && <p className="text-red-500 text-sm">{error}</p>}

          <Button
            type="submit"
            className="w-full"
            disabled={loading || passwordStrength < 2}
          >
            {loading ? "Creating account..." : "Create account"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}