"use client";

import { useAuth } from "@/context/AuthContext";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useEffect } from "react";

export default function ClientProfilePage() {
  const { user, isAuthenticated } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login");
    }
  }, [isAuthenticated, router]);

  if (!user) {
    return <div className="text-center py-20">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-bold">Your Profile</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold text-gray-700">Email</h3>
              <p className="text-gray-900">{user.email}</p>
            </div>

            {user.full_name && (
              <div>
                <h3 className="font-semibold text-gray-700">Full Name</h3>
                <p className="text-gray-900">{user.full_name}</p>
              </div>
            )}

            {user.company_name && (
              <div>
                <h3 className="font-semibold text-gray-700">Company Name</h3>
                <p className="text-gray-900">{user.company_name}</p>
              </div>
            )}

            <div>
              <h3 className="font-semibold text-gray-700">Role</h3>
              <p className="text-gray-900 capitalize">{user.role}</p>
            </div>

            <Button
              onClick={() => router.push("/client/profile/edit")}
              className="mt-6 w-full"
            >
              Edit Profile
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
